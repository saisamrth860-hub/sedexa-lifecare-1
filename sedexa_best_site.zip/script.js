// --- Data (same as React version but simpler) ---
const PRODUCTS = [
  {id:'p1',name:'Nitrile Hand Gloves',category:'surgical',tagline:'Durable protection for medical use',desc:'Disposable synthetic rubber gloves that protect against chemicals, punctures, and infectious agents.',image:'https://images.unsplash.com/photo-1588776814546-77959d4305f2?q=80&w=1200&auto=format&fit=crop',rating:4.8,inStock:true},
  {id:'p2',name:'3-Ply Face Masks',category:'surgical',tagline:'Effective multi-layer protection',desc:'Disposable masks designed for protection against airborne particles and droplets.',image:'https://images.unsplash.com/photo-1584452964155-ef139340f0db?q=80&w=1200&auto=format&fit=crop',rating:4.7,inStock:true},
  {id:'p3',name:'Mortar & Pestle',category:'ayurveda',tagline:'Traditional Ayurveda tool',desc:'Durable equipment for grinding herbal and pharmaceutical formulations.',image:'https://images.unsplash.com/photo-1631443460602-bfe63c19e781?q=80&w=1200&auto=format&fit=crop',rating:4.5,inStock:true},
  {id:'p4',name:'Enema Kits & Basti Nozzles',category:'ayurveda',tagline:'For Ayurvedic and clinical practice',desc:'Specialized equipment used in Panchakarma therapy and clinical applications.',image:'https://images.unsplash.com/photo-1584308972272-9f2db7dfd2fa?q=80&w=1200&auto=format&fit=crop',rating:4.4,inStock:true},
  {id:'p5',name:'PPE Kit',category:'hygiene',tagline:'Comprehensive COVID protection',desc:'Includes gown, mask, gloves, and sanitizer for infection control.',image:'https://images.unsplash.com/photo-1603398938378-dbf4d3e6c4de?q=80&w=1200&auto=format&fit=crop',rating:4.6,inStock:true},
  {id:'p6',name:'Cosmetic Range',category:'cosmetics',tagline:'Affordable personal care',desc:'Wide choice of cosmetics for skincare and wellness (details available on request).',image:'https://images.unsplash.com/photo-1585238341986-08f6b5d6d0e0?q=80&w=1200&auto=format&fit=crop',rating:4.2,inStock:true},
  {id:'p7',name:'Scuba Mask',category:'others',tagline:'For recreational diving',desc:'Protective diving mask, featured as part of Sedexa’s extended catalog.',image:'https://images.unsplash.com/photo-1623402278683-2f90f1f4a3ad?q=80&w=1200&auto=format&fit=crop',rating:4.0,inStock:true},
  {id:'p8',name:'Imported Buffon Cap',category:'others',tagline:'Protective headwear',desc:'Headwear accessory featured in Sedexa’s broader product portfolio.',image:'https://images.unsplash.com/photo-1617039461454-0a88b4aa1ed6?q=80&w=1200&auto=format&fit=crop',rating:3.9,inStock:true},
];

const BLOGS = [
  {id:'b1', title:'Why Quality in Surgical Supplies Matters', excerpt:'How Sedexa Lifecare ensures safety and consistency in gloves and masks.', date:'2025-07-25'},
  {id:'b2', title:'Ayurveda Equipment: Blending Tradition and Reliability', excerpt:'Exploring Panchakarma tools and their modern clinical relevance.', date:'2025-06-10'},
  {id:'b3', title:'Timely Delivery Across India: Our Logistics Strength', excerpt:'How Sedexa Lifecare fulfills nationwide healthcare supply needs.', date:'2025-05-05'},
];

const TESTIMONIALS = [
  {id:'t1', name:'Dr. Kavita Mehra', title:'Ayurvedic Practitioner, Pune', quote:'Sedexa Lifecare’s Panchakarma equipment is reliable and consistent — essential for daily practice.'},
  {id:'t2', name:'Ramesh Patel', title:'Hospital Procurement Officer, Ahmedabad', quote:'We depend on Sedexa’s surgical supplies for bulk orders. Timely delivery and good support make them a trusted partner.'},
];

// --- Render products ---
function renderProducts(filter='all'){
  const grid = document.getElementById('productGrid');
  grid.innerHTML = '';
  const list = filter==='all' ? PRODUCTS : PRODUCTS.filter(p=>p.category===filter);
  list.forEach(p=>{
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <img src="${p.image}" alt="${p.name}">
      <div class="content">
        <div class="badge">${p.category}</div>
        <h3>${p.name}</h3>
        <p class="muted">${p.tagline}</p>
        <p class="small">${p.desc}</p>
        <p class="small">${p.inStock ? '✅ In Stock' : '❌ Out of Stock'}</p>
      </div>`;
    grid.appendChild(card);
  });
}

// --- Render blogs ---
function renderBlogs(){
  const grid = document.getElementById('blogGrid');
  BLOGS.forEach(b=>{
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <div class="content">
        <h3>${b.title}</h3>
        <p class="small muted">${b.excerpt}</p>
        <p class="tiny muted">${new Date(b.date).toDateString()}</p>
        <a href="#" class="btn" style="margin-top:8px">Read More</a>
      </div>`;
    grid.appendChild(card);
  });
}

// --- Render testimonials ---
function renderTestimonials(){
  const grid = document.getElementById('testGrid');
  TESTIMONIALS.forEach(t=>{
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <div class="content">
        <p class="italic">“${t.quote}”</p>
        <p><strong>${t.name}</strong></p>
        <p class="tiny muted">${t.title}</p>
      </div>`;
    grid.appendChild(card);
  });
}

// --- Filters ---
document.getElementById('filters').addEventListener('click', (e)=>{
  const btn = e.target.closest('button[data-filter]');
  if(!btn) return;
  document.querySelectorAll('.chip').forEach(c=>c.classList.remove('active'));
  btn.classList.add('active');
  renderProducts(btn.dataset.filter);
});

// --- Enquiry form -> mailto ---
document.getElementById('enquiryForm').addEventListener('submit', (e)=>{
  e.preventDefault();
  const fd = new FormData(e.currentTarget);
  const msg = `Name: ${fd.get('name')}
Phone: ${fd.get('phone')}
Message: ${fd.get('message')||''}`;
  window.location.href = `mailto:sedexalifecare@gmail.com?subject=Website%20Enquiry&body=${encodeURIComponent(msg)}`;
});

// --- Back to top ---
const toTop = document.getElementById('toTop');
toTop.addEventListener('click', ()=> window.scrollTo({top:0, behavior:'smooth'}));
window.addEventListener('scroll', ()=>{
  toTop.style.display = window.scrollY>300 ? 'block' : 'none';
});

// --- Mobile menu ---
document.getElementById('menuBtn').addEventListener('click', ()=>{
  document.getElementById('menu').classList.toggle('show');
});

// --- Year ---
document.getElementById('year').textContent = new Date().getFullYear();

// --- Initial render ---
renderProducts();
renderBlogs();
renderTestimonials();
